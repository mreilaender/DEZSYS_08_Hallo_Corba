CLASSPATH=build/classes:$CLASSPATH
export CLASSPATH

../../../bin/jaco demo.notification.whiteboard.Workgroup
